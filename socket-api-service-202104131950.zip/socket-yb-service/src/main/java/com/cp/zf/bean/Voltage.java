package com.cp.zf.bean;

import lombok.Data;

/**
 * @Description TODO .</br>
 * <></>
 * @Author gu
 * @Date 2021/1/24 22:53
 * @Version 1.0.0
 **/
@Data
public class Voltage {
    private Integer cardid;
    private Integer v;
    private String newV;
}
