package com.cp.zf.bean;

import lombok.Data;

/**
 * @Description TODO .</br>
 * <></>
 * @Author gu
 * @Date 2021/1/25 0:51
 * @Version 1.0.0
 **/
@Data
public class Layer {
    private Integer id;
    private Double minx;
    private Double miny;
    private Double maxx;
    private Double maxy;
}
