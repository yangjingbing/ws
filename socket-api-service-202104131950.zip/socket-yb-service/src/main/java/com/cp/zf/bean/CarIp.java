package com.cp.zf.bean;

import lombok.Data;

/**
 * @Description Car Ip .</br>
 * <></>
 * @Author gu
 * @Date 2021/2/18 17:46
 * @Version 1.0.0
 **/
@Data
public class CarIp {
    private String ip;
    private Integer qyid;
}
