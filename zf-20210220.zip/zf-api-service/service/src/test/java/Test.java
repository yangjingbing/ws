import java.time.LocalDateTime;
import java.time.ZoneOffset;

/**
 * @Description TODO .</br>
 * <></>
 * @Author gu
 * @Date 2021/1/14 12:02
 * @Version 1.0.0
 **/
public class Test {
   @org.junit.Test
    public void Test(){
       System.out.println(LocalDateTime.now().minusMinutes(3));
       System.out.println(LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli());
    }
}
