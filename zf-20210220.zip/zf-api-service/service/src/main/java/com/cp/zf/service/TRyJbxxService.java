package com.cp.zf.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cp.zf.entity.TRyJbxx;

/**
 * <p>
 *  联系人服务类
 * </p>
 *
 * @author cpgu
 * @since 2021-01-12
 */
public interface TRyJbxxService extends IService<TRyJbxx> {

}
