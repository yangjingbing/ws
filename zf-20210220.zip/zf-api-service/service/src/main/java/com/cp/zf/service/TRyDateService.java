package com.cp.zf.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cp.zf.entity.TRyDate;

/**
 * <p>
 * 人员有效时间 服务类
 * </p>
 *
 * @author cpgu
 * @since 2021-02-18
 */
public interface TRyDateService extends IService<TRyDate> {

}
