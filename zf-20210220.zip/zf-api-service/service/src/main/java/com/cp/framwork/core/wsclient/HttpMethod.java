package com.cp.framwork.core.wsclient;


public enum HttpMethod {
    GET, POST, DELETE;
}
