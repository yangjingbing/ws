package com.cp.zf.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cp.zf.entity.TCarInfo;

/**
 * <p>
 * 车辆基本信息 服务类
 * </p>
 *
 * @author cpgu
 * @since 2021-02-18
 */
public interface TCarInfoService extends IService<TCarInfo> {

}
