package com.cp.zf.service.impl;

import com.alibaba.fastjson.JSON;
import com.cp.zf.entity.TCarInfo;
import com.cp.zf.entity.TRyDate;
import com.cp.zf.entity.TRyJbxx;
import com.cp.zf.input.CarInput;
import com.cp.zf.input.PersonInput;
import com.cp.zf.service.TCarInfoService;
import com.cp.zf.service.TRyDateService;
import com.cp.zf.service.TRyJbxxService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description 审核通过service .</br>
 * <></>
 * @Author gu
 * @Date 2021/2/18 21:25
 * @Version 1.0.0
 **/
@Slf4j
@Service
public class EgisService {

    @Autowired
    private TRyJbxxService tRyJbxxService;
    @Autowired
    private TRyDateService tRyDateService;
    @Autowired
    private TCarInfoService tCarInfoService;

    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = {Exception.class, Error.class})
    public void personInfo(List<PersonInput> personList) throws Exception {
        if (CollectionUtils.isEmpty(personList)) {
            log.info("人员集合为空。");
            return;
        }
        log.info("人员：{}", JSON.toJSONString(personList));

        tRyJbxxService.saveBatch(personList.stream().map(TRyJbxx::of).collect(Collectors.toList()));

        tRyDateService.saveBatch(personList.stream().map(TRyDate::of).collect(Collectors.toList()));

    }




    @Transactional(isolation = Isolation.READ_COMMITTED, rollbackFor = {Exception.class, Error.class})
    public void carInfo(List<CarInput> carList) throws Exception {
        if (CollectionUtils.isEmpty(carList)) {
            log.info("车辆集合为空。");
            return;
        }
        log.info("车辆：{}", JSON.toJSONString(carList));

        tCarInfoService.saveBatch(carList.stream().map(TCarInfo::of).collect(Collectors.toList()));

    }
}
