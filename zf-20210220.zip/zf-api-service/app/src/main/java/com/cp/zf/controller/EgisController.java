package com.cp.zf.controller;

import com.cp.framwork.core.ApiResponse;
import com.cp.framwork.core.ApiResponseFactory;
import com.cp.zf.input.CarInput;
import com.cp.zf.input.PersonInput;
import com.cp.zf.service.impl.EgisService;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Description 审核通过controller .</br>
 * <></>
 * @Author gu
 * @Date 2021/2/1 19:10
 * @Version 1.0.0
 **/
@RestController
@RequestMapping("/{version}/zf/egis")
public class EgisController {

    @Autowired
    private EgisService egisService;

    @ApiOperation("人员审核通过")
    @PostMapping("/user")
    public ApiResponse userEgis(@RequestBody List<PersonInput> personList) throws Exception {
        egisService.personInfo(personList);
        return ApiResponseFactory.get("ok");
    }

    @ApiOperation("车辆审核通过")
    @PostMapping("/car")
    public ApiResponse carEgis(@RequestBody List<CarInput> carList) throws Exception {
        egisService.carInfo(carList);
        return ApiResponseFactory.get("ok");
    }
}
