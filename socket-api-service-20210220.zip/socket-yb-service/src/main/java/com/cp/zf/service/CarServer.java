package com.cp.zf.service;

import com.alibaba.fastjson.JSONObject;
import com.cp.zf.bean.CarColor;
import com.cp.zf.bean.CarIp;
import com.cp.zf.bean.Voltage;
import com.cp.zf.util.HttpClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @Description TODO .</br>
 * <></>
 * @Author gu
 * @Date 2021/1/26 11:16
 * @Version 1.0.0
 **/
public class CarServer {

    static Pattern r = Pattern.compile("\\d*");


    public static void carInfo(JdbcTemplate jdbcTemplate, long lastt) {

        Date date1 = new Date(lastt);

        Calendar rightNow = Calendar.getInstance();
        rightNow.setTime(date1);
        rightNow.add(13, -20);
        Date date = rightNow.getTime();

        String nowTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);

        Timestamp tt = Timestamp.valueOf(nowTime);

        //t_car
        String listSql = "SELECT carnum,COUNT(1) n,description,dt,sip FROM t_car t WHERE LEFT(t.description,2)<>'卡号' and dt>=? GROUP  BY t.description ";
        List<Map<String, Object>> result = jdbcTemplate.query(listSql, new Object[]{tt}, new RowMapper() {
            public Map mapRow(ResultSet rs, int rowNum)
                    throws SQLException {
                Map<String, Object> row = new LinkedHashMap();
                try {
                    row.put("carnum", rs.getString("carnum"));
                    if (!Objects.isNull(rs.getString("carnum"))) {
                        row.put("carColor", rs.getString("carnum").substring(0, 1));
                    }
                    row.put("description", rs.getString("description"));
                    row.put("n", Integer.valueOf(rs.getInt("n")));
                    long tt = rs.getTimestamp("dt").getTime();
                    row.put("timestamp", Long.valueOf(tt));
                    row.put("sip", rs.getString("sip"));
                    //获取sn(人员卡卡号)
                    Matcher matcher = r.matcher(rs.getString("description"));
                    if (matcher.find()) {
                        row.put("sn", matcher.group(0));
                    }

                    return row;
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
                return null;
            }
        });

        if (!result.isEmpty()) {
            List<String> cardIdList = new ArrayList<>();
            List<String> ipList = new ArrayList<>();
            for (Iterator<Map<String, Object>> iterator = result.iterator(); iterator.hasNext(); ) {
                Map<String, Object> tmpMap = iterator.next();
                cardIdList.add(tmpMap.getOrDefault("sn", "").toString());
                ipList.add(tmpMap.getOrDefault("sip", "").toString());
            }
            //t_ryk_jbxx
            listSql = "SELECT sn,ryid FROM t_ryk_jbxx where sn in ('" + cardIdList.stream().collect(Collectors.joining("','")) + "') ";
            List<Map<String, Object>> personList = jdbcTemplate.query(listSql, new RowMapper() {
                public Map mapRow(ResultSet rs, int rowNum)
                        throws SQLException {
                    Map row = new LinkedHashMap();
                    try {
                        row.put("sn", rs.getInt("sn"));
                        row.put("ryid", Integer.valueOf(rs.getInt("ryid")));
                        return row;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                    return null;
                }
            });

            //t_rssi
            listSql = "SELECT cardid, v FROM t_rssi WHERE cardid in ('" + cardIdList.stream().collect(Collectors.joining("','")) + "')";
            List<Voltage> voltageResult = jdbcTemplate.query(listSql, new RowMapper() {
                public Voltage mapRow(ResultSet rs, int rowNum)
                        throws SQLException {
                    Voltage voltage = new Voltage();
                    try {
                        voltage.setV(rs.getInt("v") / 100);
                        voltage.setCardid(rs.getInt("cardid"));
                        return voltage;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                    return null;
                }
            });

            //t_car_ip
            listSql = "SELECT ip, qyid FROM t_car_ip WHERE ip in ('" + ipList.stream().collect(Collectors.joining("','")) + "')";
            List<CarIp> carIpResult = jdbcTemplate.query(listSql, new RowMapper() {
                public CarIp mapRow(ResultSet rs, int rowNum)
                        throws SQLException {
                    CarIp carIp = new CarIp();
                    try {
                        carIp.setIp(rs.getString("ip"));
                        carIp.setQyid(rs.getInt("qyid"));
                        return carIp;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                    return null;
                }
            });

            //t_car_color
            listSql = "SELECT id, mc FROM t_car_color";
            List<CarColor> carColorResult = jdbcTemplate.query(listSql, new RowMapper() {
                public CarColor mapRow(ResultSet rs, int rowNum)
                        throws SQLException {
                    CarColor carColor = new CarColor();
                    try {
                        carColor.setId(rs.getInt("id"));
                        carColor.setMc(rs.getString("mc"));
                        return carColor;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                    return null;
                }
            });

            //电压值
            Map<Integer, Integer> voltageMap = new HashMap<>();
            if (!voltageResult.isEmpty()) {
                voltageMap = voltageResult.stream().collect(Collectors.toMap(Voltage::getCardid, Voltage::getV, (x1, x2) -> x1));
            }

            //卡扣编号
            Map<String, Integer> kkbhMap = new HashMap<>();
            if (!carIpResult.isEmpty()) {
                kkbhMap = carIpResult.stream().collect(Collectors.toMap(CarIp::getIp, CarIp::getQyid, (x1, x2) -> x1));
            }

            //颜色编码
            Map<String, Integer> colorCodeMap = new HashMap<>();
            if (!carColorResult.isEmpty()) {
                colorCodeMap = carColorResult.stream().collect(Collectors.toMap(CarColor::getMc, CarColor::getId));
            }

            Map<String, Object> sendResultMap = new HashMap<>();
            for (Iterator<Map<String, Object>> iterator = result.iterator(); iterator.hasNext(); ) {
                Map<String, Object> map = iterator.next();
                sendResultMap.put("CarId", map.get("carnum"));  //车牌号
                sendResultMap.put("Car_color", colorCodeMap.getOrDefault(map.getOrDefault("carColor", ""), null));  //车牌颜色
                sendResultMap.put("Car_PeoNum", map.get("n"));  //车上人员卡数量

                //7天未进入园区，进入的话传送一个状态为0，否则的话传送为1
                Instant timestamp = Instant.ofEpochMilli(Long.parseLong(map.get("timestamp").toString()));
                ZonedDateTime losAngelesTime = timestamp.atZone(ZoneId.of("Asia/Shanghai"));
                long between1DAYS = ChronoUnit.DAYS.between(losAngelesTime.toLocalDate(), LocalDate.now());
                sendResultMap.put("Status", "0");  //正常通行
                if (between1DAYS >= 7) {
                    sendResultMap.put("Status", "1");  //车辆通行状况
                }
                sendResultMap.put("Timestamp", losAngelesTime.toLocalDateTime().toString());
                //人员卡具体信息
                List<Map<String, Object>> personPoints = new ArrayList<>();
                if (!CollectionUtils.isEmpty(personList)) {
                    for (Map<String, Object> info : personList) {
                        Map<String, Object> personCardMap = new HashMap<>();
                        personCardMap.put("User_id", info.get("ryid"));
                        personCardMap.put("Card_sn", info.get("sn"));
                        personCardMap.put("Volit", voltageMap.getOrDefault(info.get("sn"),null));
                        personCardMap.put("CardType", "定位卡");
                        personPoints.add(personCardMap);
                    }
                }
                sendResultMap.put("FastenerId", kkbhMap.getOrDefault(map.getOrDefault("sip", ""), null));
                sendResultMap.put("PersonPoints", personPoints);

                Map<String, Object> resultMap = new HashMap<>();
                resultMap.put("MsgType", "car");
                resultMap.put("Content", sendResultMap);
                try {
                    System.out.println("通行记录数据。");
                    HttpClient.httpPost("http://172.16.1.191:8080/park/api/accept/pass", resultMap, null);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }else{
            System.out.println("无通行记录数据。");
        }
    }


}
